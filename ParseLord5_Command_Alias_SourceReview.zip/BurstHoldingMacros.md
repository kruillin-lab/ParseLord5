---
tags:
  - type/doc
  - project/parselord5
  - status/active
type: doc
project: parselord5
status: active
aliases: []
---
# WrathCombo Burst-Holding Macros

Per upstream [Issue #99](https://github.com/PunishXIV/WrathCombo/issues/99), Burst Holding is still something planned for better support later.

As a workaround, you can create a macro to toggle off the burst parts of jobs in WrathCombo to achieve a similar result.

You can toggle off these options with `/wrath toggle <x>` in game.
You can find the ID or internal name to provide as `<x>` by using `/wrath list set <y>` (replace `<y>` with your current job, like `/wrath list set DRK`), or by looking at the [`Preset` file](https://github.com/PunishXIV/WrathCombo/blob/main/WrathCombo/Combos/CustomComboPreset.cs) (see [this image](https://i.imgur.com/LsJ06DW.png) for how to read this).

> [!Warning]
> Verify IDs with `/wrath list set <job>` before relying on macros. Preset IDs can change as WrathCombo and ParseLord5 continue to evolve.

ParseLord5 preserves the WrathCombo `/wrath` command for these examples. `/pl5` is also available as an alias, but the macro examples below intentionally stay on `/wrath`.

Below is a community-provided list of basic burst-holding macros for each job.

### <img src="https://ffxiv.gamerescape.com/w/images/6/6b/Tank_Icon_1.png" width="20px" height="20px" /> Tank
<details>
<summary>PLD</summary>

```
/wrath toggle 11003
/wrath toggle 11016
/wrath toggle 11010
/wrath toggle 11019
```

</details>
<details>
<summary>WAR</summary>

```
/wrath toggle 18003
/wrath toggle 18019
/wrath toggle 18007
/wrath toggle 18018
```

</details>
<details>
<summary>DRK</summary>

```
/wrath toggle 5015
/wrath toggle 5054
/wrath toggle 5016
/wrath toggle 5055
/wrath toggle 5018
/wrath toggle 5057
```

</details>
<details>
<summary>GNB</summary>

```
/wrath toggle 7008
/wrath toggle 7201
/wrath toggle 7011
/wrath toggle 7204
```

</details>

### <img src="https://ffxiv.gamerescape.com/w/images/d/d6/Healer_Icon_1.png" width="20px" height="20px" /> Healer

<details>
<summary>WHM</summary>

```
/wrath toggle 19008
/wrath toggle 19195
```

</details>
<details>
<summary>SCH</summary>

```
/wrath toggle 16003
/wrath toggle 16054
```

</details>
<details>
<summary>AST</summary>

```
/wrath toggle 1043
/wrath toggle 1016
```

</details>
<details>
<summary>SGE</summary>

```
/wrath toggle 14051
/wrath toggle 14010
/wrath toggle 14008
/wrath toggle 14005
```

</details>

### <img src="https://ffxiv.gamerescape.com/w/images/2/29/Melee_DPS_Icon_1.png" width="20px" height="20px" /> Melee
<details>
<summary>DRG</summary>

```
/wrath toggle 6103
/wrath toggle 6104
/wrath toggle 6203
/wrath toggle 6204
/wrath toggle 6107
/wrath toggle 6207
/wrath toggle 6106
/wrath toggle 6206
```

</details>
<details>
<summary>MNK</summary>

```
/wrath toggle 9009
/wrath toggle 9030
/wrath toggle 9032
/wrath toggle 9011
```

</details>
<details>
<summary>NIN</summary>

```
/wrath toggle 10006
/wrath toggle 10007
/wrath toggle 10022
/wrath toggle 10023
```

</details>
<details>
<summary>SAM</summary>

```
/wrath toggle 15012
/wrath toggle 15108
/wrath toggle 15018
/wrath toggle 15114
```

</details>
<details>
<summary>RPR</summary>

```
/wrath toggle 12009
/wrath toggle 12108
/wrath toggle 12006
/wrath toggle 12105
```

</details>
<details>
<summary>VPR</summary>

```
/wrath toggle 30005
/wrath toggle 30011
/wrath toggle 30104
/wrath toggle 30110
/wrath toggle 30112
```

</details>

### <img src="https://ffxiv.gamerescape.com/w/images/3/3d/Physical_Ranged_DPS_Icon_1.png" width="20px" height="20px" /> Ranged
<details>
<summary>BRD</summary>

```
/wrath toggle 3017
/wrath toggle 3032
```

</details>
<details>
<summary>MCH</summary>

```
/wrath toggle 8110
/wrath toggle 8108
/wrath toggle 8107
/wrath toggle 8103
/wrath toggle 8119

/wrath toggle 8301
/wrath toggle 8304
/wrath toggle 8307
/wrath toggle 8315
```

</details>
<details>
<summary>DNC</summary>

```
/wrath toggle 4015
/wrath toggle 4018
/wrath toggle 4028
/wrath toggle 4021
/wrath toggle 4022
/wrath toggle 4046
/wrath toggle 4047
/wrath toggle 4055
/wrath toggle 4048
/wrath toggle 4049
/wrath toggle 4052
```

</details>

### <img src="https://ffxiv.gamerescape.com/w/images/6/65/Magic_Ranged_DPS_Icon_1.png" width="20px" height="20px" /> Caster
<details>
<summary>BLM</summary>

```
/wrath toggle 2103
/wrath toggle 2202
/wrath toggle 2102
/wrath toggle 2201
```

</details>
<details>
<summary>SMN</summary>

```
/wrath toggle 17053
/wrath toggle 17017
/wrath toggle 17020
/wrath toggle 17061
```

</details>
<details>
<summary>RDM</summary>

```
/wrath toggle 13010
/wrath toggle 13207
/wrath toggle 13011
/wrath toggle 13208
```

</details>
<details>
<summary>PCT</summary>

```
/wrath toggle 20021
/wrath toggle 20054
/wrath toggle 20027
/wrath toggle 20060
```

</details>
